%Expected outcome:
% ERROR UnknownClause

p :- a.

query(p).