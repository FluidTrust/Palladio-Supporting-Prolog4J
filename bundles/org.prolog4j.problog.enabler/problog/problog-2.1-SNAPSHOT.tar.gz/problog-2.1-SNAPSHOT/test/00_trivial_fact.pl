%Expected outcome:
% a 0.3
% b 0.5

0.3::a.
0.5::b.

query(a).
query(b).
