0.6::b.
c :- a, b.
?::a.
utility(c,3).