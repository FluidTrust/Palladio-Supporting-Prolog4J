?::a.
0.6::b :- a.
?::c :- b.
utility(c,3).