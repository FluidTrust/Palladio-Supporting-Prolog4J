0.6::b.
?::c :- b.
utility(c,3).