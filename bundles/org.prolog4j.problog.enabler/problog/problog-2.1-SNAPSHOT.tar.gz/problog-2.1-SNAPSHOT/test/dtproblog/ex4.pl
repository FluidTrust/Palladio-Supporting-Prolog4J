?::b.
?::c :- b.
utility(c,3).