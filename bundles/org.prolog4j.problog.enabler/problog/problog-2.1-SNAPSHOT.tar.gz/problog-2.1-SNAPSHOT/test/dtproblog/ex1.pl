?::b.
0.6::c :- b.
utility(c,3).