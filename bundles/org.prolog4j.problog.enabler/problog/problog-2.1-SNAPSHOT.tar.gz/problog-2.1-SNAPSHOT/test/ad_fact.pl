%Expected outcome:
% p(1) 0.3
% p(2) 0.4

0.3::p(1); 0.4::p(2).

query(p(X)).