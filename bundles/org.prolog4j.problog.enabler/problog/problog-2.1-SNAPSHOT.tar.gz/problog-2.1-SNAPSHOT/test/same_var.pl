%Expected outcome:
% score 0

in(a,b).

score :- in(X,X).

query(score).