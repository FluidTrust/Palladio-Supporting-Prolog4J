%Expected outcome:
% a 0.3

P::a :- P=0.3.


query(a).
% query(b).