%Expected outcome:
% p 0

:- unknown(fail).

p :- a.

query(p).