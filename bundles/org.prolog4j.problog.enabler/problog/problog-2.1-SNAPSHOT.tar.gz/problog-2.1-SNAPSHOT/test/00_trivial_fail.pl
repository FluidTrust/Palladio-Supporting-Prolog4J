%Expected outcome:
% a 0.0

a :- fail.

query(a).
