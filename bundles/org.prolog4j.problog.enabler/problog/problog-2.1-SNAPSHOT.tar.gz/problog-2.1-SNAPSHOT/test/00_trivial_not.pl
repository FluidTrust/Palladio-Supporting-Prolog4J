%Expected outcome:
% p 0.6

0.4::a.

p :- \+a.

query(p).