%Expected outcome:
% 0.75::a(X); 0.25::b(X).
t(_)::a(X) ; t(_)::b(X).