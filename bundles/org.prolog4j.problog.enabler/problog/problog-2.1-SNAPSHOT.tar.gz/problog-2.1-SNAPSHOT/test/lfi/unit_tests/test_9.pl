%Expected outcome:
% 0.75::b; 0.25::c.
% 1.0::a :- b.

t(_)::b; t(_)::c.
t(_)::a:-b.