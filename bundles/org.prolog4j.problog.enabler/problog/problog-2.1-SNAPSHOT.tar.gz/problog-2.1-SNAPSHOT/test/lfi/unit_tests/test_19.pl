%Expected outcome:
% 0.6::a(X); 0.4::b(X).

t(_)::a(X); t(_)::b(X).