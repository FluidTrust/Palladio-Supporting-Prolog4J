%Expected outcome:
% 1.0::b(X).
% 0.5::a(X) :- b(X).

t(_)::b(X).
0.5::a(X) :- b(X).