%Expected outcome:
% 1.0::b.
% 0.5::a :- b.

t(_)::b.
0.5::a:-b.