%Expected outcome:
% 1.0::b(X).
% 1.0::a(X) :- b(X).

t(_)::b(X).
t(_)::a(X) :- b(X).