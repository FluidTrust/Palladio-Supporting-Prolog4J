%Expected outcome:
% 0.75::a(X).
% 0.5::b(X).

t(_)::a(X).
t(_)::b(X).