%Expected outcome:
% 1.0::b.
% 1.0::a :- b.

t(_)::b.
t(_)::a:-b.