%Expected outcome:
% 0.5::b(X).
% 0.5::a(X) :- b(X).

t(_)::b(X).
t(_)::a(X) :- b(X).