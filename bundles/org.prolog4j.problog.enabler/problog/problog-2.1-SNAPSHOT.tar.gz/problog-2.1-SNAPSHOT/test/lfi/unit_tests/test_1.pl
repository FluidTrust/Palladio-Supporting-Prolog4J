%Expected outcome:
% 1.0::a.
% 1.0::b.

t(_)::a.
t(_)::b.