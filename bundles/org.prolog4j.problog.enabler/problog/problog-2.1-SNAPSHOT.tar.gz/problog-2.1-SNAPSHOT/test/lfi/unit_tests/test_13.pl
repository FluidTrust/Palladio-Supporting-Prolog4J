%Expected outcome:
% 1.0::a(X).
% 1.0::b(X).

t(_)::a(X).
t(_)::b(X).