%Expected outcome:
% 0.75::b.
% 0.5::a :- b.

t(_)::b.
t(_)::a :- b.
