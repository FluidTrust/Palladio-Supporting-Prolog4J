%Expected outcome:
% 0.75::a.
% 1.0::b.

t(_)::a.
t(_)::b.

