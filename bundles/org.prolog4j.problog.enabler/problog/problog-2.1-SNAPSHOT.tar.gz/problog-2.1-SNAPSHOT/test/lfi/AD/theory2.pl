%Expected outcome:
% 0.75::a(1); 0.25::b(1).

t(_)::a(1); t(_)::b(1).