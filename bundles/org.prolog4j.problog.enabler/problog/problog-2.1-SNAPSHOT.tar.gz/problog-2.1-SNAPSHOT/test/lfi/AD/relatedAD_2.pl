%Expected outcome:
% error: NonGroundProbabilisticClause

t(_)::a(X); t(_)::b(Y).