%Expected outcome:
% 0.75::a(1); 0.25::a(2).

t(_)::a(1); t(_)::a(2).