
theory1 - theory 5 are different encodings to the same program.
They should give should give the same result.


