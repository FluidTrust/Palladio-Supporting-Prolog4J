%Expected outcome:
% 0.75::a; 0.25::b.

t(_)::a; t(_)::b.