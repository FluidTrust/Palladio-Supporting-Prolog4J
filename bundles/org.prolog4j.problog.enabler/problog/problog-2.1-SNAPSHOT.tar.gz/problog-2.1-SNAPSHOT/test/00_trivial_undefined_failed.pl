%Expected outcome:
% a 0

:- unknown(fail).

query(a).