%Expected outcome:
% q1 1

% Redirect query to avoid ugly list notation in output which might be fixed in the future.
q1 :- length([a,b,c],3).

query( q1 ).