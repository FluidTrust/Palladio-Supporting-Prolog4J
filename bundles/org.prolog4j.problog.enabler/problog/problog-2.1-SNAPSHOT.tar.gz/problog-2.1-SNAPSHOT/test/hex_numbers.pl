
q :- A = 0x10, B = 16, A = B.

(1/0x10)::r.

query(q). % outcome: 1

query(r). % outcome: 0.0625