%Expected outcome:
% ERROR UnknownClause

query(a).