%Expected outcome: 
% heads1 0.5
% heads2 0.6
% twoHeads 0.3
% burglary 0.9896551724137932
% earthquake 0.2275862068965517

:- consult('00_trivial_and').
:- consult('4_bayesian_net').