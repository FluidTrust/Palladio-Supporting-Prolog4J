p(.(a,.(b,[]))). 

query(p(L)).