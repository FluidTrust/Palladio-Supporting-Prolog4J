binary(X,Y) :- X & Y.
