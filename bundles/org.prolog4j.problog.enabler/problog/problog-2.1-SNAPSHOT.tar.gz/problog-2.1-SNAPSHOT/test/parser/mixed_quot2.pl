second_mixed(X) :- 'qsdf".
