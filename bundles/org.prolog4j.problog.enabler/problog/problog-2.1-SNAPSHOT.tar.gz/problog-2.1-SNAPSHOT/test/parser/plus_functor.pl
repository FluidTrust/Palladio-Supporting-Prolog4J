p(L) :- L is '+'(1,2).

query(p(L)).