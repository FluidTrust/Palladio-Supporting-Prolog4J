dquot(X) :- X == "qsdf\"qsdf".
squot(X) :- X == 'qsdf\'qsdf'.
