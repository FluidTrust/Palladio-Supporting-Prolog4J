/* abc 


query(p).