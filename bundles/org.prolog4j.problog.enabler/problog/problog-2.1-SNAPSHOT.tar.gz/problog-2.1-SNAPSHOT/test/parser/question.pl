queston(X,Y) :- X ? Y.
