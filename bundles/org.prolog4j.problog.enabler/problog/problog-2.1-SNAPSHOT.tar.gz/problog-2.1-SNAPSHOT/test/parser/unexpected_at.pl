wrong_char_after_at(X,Y) :- X @= Y.
