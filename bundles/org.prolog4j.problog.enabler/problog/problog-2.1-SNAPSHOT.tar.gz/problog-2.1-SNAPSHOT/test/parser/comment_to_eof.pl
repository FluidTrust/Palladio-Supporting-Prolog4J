% This is a comment.
p(a,b).

% This is another comment