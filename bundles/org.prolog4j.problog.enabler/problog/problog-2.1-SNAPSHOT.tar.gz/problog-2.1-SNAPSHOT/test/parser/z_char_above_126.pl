micro(X) :- µ X. %%line 378 not calleble if None.
