mixed(X) :- X == "qsdf'.
