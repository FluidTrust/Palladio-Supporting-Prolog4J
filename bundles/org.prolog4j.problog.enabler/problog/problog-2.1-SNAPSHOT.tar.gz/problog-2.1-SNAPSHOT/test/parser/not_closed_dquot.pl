0.5::check(X) :- X == "qsdf.
