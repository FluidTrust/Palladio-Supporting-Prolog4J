%Expected outcome: 
% a 0.3103448275862069

0.2 :: r <- a.
0.2 :: h <- r.
0.2 :: a. 
0.2 :: r. 

evidence(h,true).
query(a).