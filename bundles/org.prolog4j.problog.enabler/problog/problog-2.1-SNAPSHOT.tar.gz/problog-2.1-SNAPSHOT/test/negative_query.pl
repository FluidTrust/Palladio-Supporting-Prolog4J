%Expected outcome:
%  \+p 0.7

0.3::p.

query(\+p).