%Expected outcome:
% a 1.0

a.

query(a).
