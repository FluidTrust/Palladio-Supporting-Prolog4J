.. ProbLog documentation master file, created by
   sphinx-quickstart on Sat Oct 18 13:56:48 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ProbLog
=======

Welcome to the ProbLog 2.1 documentation.

Contents:

.. toctree::
   :maxdepth: 3
   :numbered:

   install
   modeling_basic
   cli
   prolog
   faq
   api
.. notes
..   engine   

   
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
