from .tasks import main
import sys

if __name__ == "__main__":
    main(sys.argv[1:])
