%%% The data:
evidence(burglary,false).
evidence(alarm,false).
-----
evidence(earthquake,false).
evidence(alarm,true).
evidence(burglary,true).
-----
evidence(burglary,false).