/*  Creator: make/0

    Purpose: Provide index for autoload
*/

index((unicode_block), 3, unicode_blocks, blocks).
index((unicode_property), 2, unicode_data, unicode_data).
